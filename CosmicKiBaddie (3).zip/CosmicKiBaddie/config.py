"""
Cosmic ki baddie — Configuration Module
Server: Side Quest Studio
Provides environment-backed configuration defaults, theme colors, and runtime constants.
No role IDs, channel IDs, or bot tokens are hardcoded.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


@dataclass(frozen=True)
class ThemePalette:
    """Brand color palette for Cosmic ki baddie (Side Quest Studio)."""

    PRIMARY: int = 0x8B5CF6      # Cosmic Violet
    SECONDARY: int = 0xEC4899    # Nebula Pink
    ACCENT: int = 0x06B6D4       # Starlight Cyan
    SUCCESS: int = 0x10B981      # Emerald Green
    WARNING: int = 0xF59E0B      # Solar Amber
    DANGER: int = 0xEF4444       # Supernova Red
    INFO: int = 0x3B82F6         # Astral Blue
    NEUTRAL: int = 0x1E1B4B      # Deep Space Indigo


@dataclass
class BotConfig:
    """Central runtime configuration loaded from environment variables."""

    bot_name: str = field(default_factory=lambda: os.getenv("BOT_NAME", "Cosmic ki baddie"))
    community_name: str = field(default_factory=lambda: os.getenv("COMMUNITY_NAME", "Side Quest Studio"))
    token: str = field(default_factory=lambda: os.getenv("DISCORD_TOKEN", ""))
    default_prefix: str = field(default_factory=lambda: os.getenv("DEFAULT_PREFIX", "!"))
    owner_ids: List[int] = field(
        default_factory=lambda: [
            int(x.strip())
            for x in os.getenv("OWNER_IDS", "").split(",")
            if x.strip().isdigit()
        ]
    )
    database_url: str = field(
        default_factory=lambda: os.getenv(
            "DATABASE_URL",
            f"sqlite:///{BASE_DIR / 'data' / 'cosmic_ki_baddie.db'}",
        )
    )
    backup_dir: Path = field(
        default_factory=lambda: Path(
            os.getenv("BACKUP_DIR", str(BASE_DIR / "data" / "backups"))
        )
    )
    transcript_dir: Path = field(
        default_factory=lambda: Path(
            os.getenv("TRANSCRIPT_DIR", str(BASE_DIR / "data" / "transcripts"))
        )
    )
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO").upper())
    sync_commands_on_startup: bool = field(
        default_factory=lambda: os.getenv("SYNC_COMMANDS_ON_STARTUP", "true").lower() in ("1", "true", "yes")
    )
    dev_guild_id: Optional[int] = field(
        default_factory=lambda: int(os.getenv("DEV_GUILD_ID"))
        if os.getenv("DEV_GUILD_ID", "").strip().isdigit()
        else None
    )
    status_text: str = field(
        default_factory=lambda: os.getenv("BOT_STATUS", "Side Quest Studio | /help")
    )
    max_Backup_retention: int = field(
        default_factory=lambda: int(os.getenv("MAX_BACKUP_RETENTION", "15"))
    )

    # Protected commands that can NEVER be disabled via /command disable to prevent server bricking
    protected_commands: tuple[str, ...] = (
        "command",
        "command enable",
        "command disable",
        "command list",
        "command permissions",
        "command cooldown",
        "command settings",
        "permissions",
        "permissions panel",
        "permissions set",
        "permissions remove",
        "permissions view",
        "permissions reset",
        "safemode",
        "protection",
        "setup",
        "help",
        "prefix",
    )

    # All modular extensions loaded by CosmicBot
    initial_extensions: tuple[str, ...] = (
        "cogs.permissions",
        "cogs.command_manager",
        "cogs.moderation",
        "cogs.logging",
        "cogs.roles",
        "cogs.automation",
        "cogs.autoresponder",
        "cogs.welcome",
        "cogs.tickets",
        "cogs.embeds",
        "cogs.antinuke",
        "cogs.protection",
        "cogs.giveaways",
        "cogs.events",
        "cogs.polls",
        "cogs.setup_wizard",
        "cogs.help",
    )


THEME = ThemePalette()
CONFIG = BotConfig()
